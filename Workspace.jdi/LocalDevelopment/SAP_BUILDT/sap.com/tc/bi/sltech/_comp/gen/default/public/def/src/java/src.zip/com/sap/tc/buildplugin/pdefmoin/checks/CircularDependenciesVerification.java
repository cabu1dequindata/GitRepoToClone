package com.sap.tc.buildplugin.pdefmoin.checks;

import java.util.*;

import com.sap.sld.api.std.sl.*;
import com.sap.sld.api.std.soft.SLD_ProductVersion;
import com.sap.sld.api.wbem.client.WBEMClient;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.util.BuildPluginException;

/**
 * Check that no circular dependencies (both LocallyRequired and CoreMember, recursively) exist
 * 
 */
public class CircularDependenciesVerification implements VerificationClass
{
	private final WBEMClient				client;
	private final List<String>				messages;
	private final Hashtable<String, String>	properties;

	public CircularDependenciesVerification(WBEMClient client, List<String> messages, Hashtable<String, String> properties)
	{
		this.client = client;
		this.messages = messages;
		this.properties = properties;
	}

	public boolean verify() throws BuildPluginException
	{
		boolean checkOK = true;

		try
		{
			List<SLD_ProductVersion> products = SLD_ProductVersion.getAllProductVersions(client);
			for (SLD_ProductVersion product : products)
			{
				String allProducts = properties.get(VerificationProperties.ALL_PRODUCTS);
				if (VerificationProperties.ALL_PRODUCTS_NO.equals(allProducts))
				{
					String productName = properties.get(VerificationProperties.PRODUCT_NAME);
					String vendor = properties.get(VerificationProperties.VENDOR);
					String versions = properties.get(VerificationProperties.VERSION);

					if (!product.getName().equals(productName) || !product.getVersion().equals(vendor) || !product.getVendor().equals(versions))
					{
						continue;
					}
				}

				List<SLD_FunctionalElement> functionalElements = product.getFunctionalElements(false);
				for (SLD_FunctionalElement fe : functionalElements)
				{
					ArrayList<SLD_FunctionalEntity> parents = new ArrayList<SLD_FunctionalEntity>();
					parents.add(fe);
					if(!checkRequirements(fe,parents))
						checkOK=false;
					if(!checkOK)
						break; // show only first error, because the same error will be found multiple times
				}
			}

		}
		catch (CIMException e)
		{
			throw new BuildPluginException("CIMException while checking if circular dependencies exist.", e);
		}

		return checkOK;
	}
	// recursively check required FE path, whether they make up a circle
	// A->B->C->D->A
	// use both required and included associations
	// return false if cyclic dependency
	private boolean checkRequirements(SLD_FunctionalEntity feParent,List<SLD_FunctionalEntity> requiredFEs) throws CIMException
	{		
		// check if one of parent's children is in the list of predecessors
		
		Set<SLD_FunctionalEntity> requiredAndIncludedFEs=new HashSet<SLD_FunctionalEntity>();
		requiredAndIncludedFEs.addAll(feParent.getRequiredFEs());
		if(feParent instanceof SLD_FunctionalElement)
			requiredAndIncludedFEs.addAll(((SLD_FunctionalElement)feParent).getCoreMembers());
		for(SLD_FunctionalEntity fe:requiredAndIncludedFEs)
		{
			StringBuffer path=new StringBuffer();
			path.append(fe.getCaption());
			// check against list of grand parents
			for(int i=requiredFEs.size()-1;i>=0;i--)
			{
				SLD_FunctionalEntity feGreatParent=requiredFEs.get(i);	
				path.append("<-");
				path.append(feGreatParent.getCaption());
				if(feGreatParent.equals(fe))
					{
					String err="Circular dependency (requirement/inclusion): " +path.toString();
					Log.error(err);
					messages.add(err);
					return false;
					}
			}
			requiredFEs.add(fe);
			if(!checkRequirements(fe, requiredFEs))
				return false; // short-circuit recursion
			requiredFEs.remove(requiredFEs.size()-1);						
		}
		return true;
	}

//	private boolean isMemberDependencyCyclic(SLD_FunctionalEntity fe, HashSet<SLD_FunctionalEntity> allFEs) throws CIMException
//	{
//		if (fe instanceof SLD_FunctionalElement)
//		{
//			if (allFEs.contains(fe))
//				return true;
//
//			allFEs.add(fe);
//
//			for (SLD_FunctionalElement functionalEntity : ((SLD_FunctionalElement) fe).getAllMembers(false))
//			{
//				return isMemberDependencyCyclic(functionalEntity, allFEs);
//			}
//		}
//
//		return false;
//	}
//
//	private boolean isRequiringDependencyCyclic(SLD_FunctionalEntity fe, HashSet<SLD_FunctionalEntity> allFEs) throws CIMException
//	{
//		if (allFEs.contains(fe))
//			return true;
//
//		allFEs.add(fe);
//
//		for (SLD_FunctionalEntity functionalEntity : fe.getRequiringFEs())
//		{
//			return isRequiringDependencyCyclic(functionalEntity, allFEs);
//		}
//
//		return false;
//	}

	public boolean abortBuild()
	{
		return true;
	}

	public String getDescription()
	{
		return "Check for circular dependencies";
	}

	public boolean stopOtherVerifications()
	{
		return true;
	}
}
