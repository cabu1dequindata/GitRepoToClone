package com.sap.tc.buildplugin.pdefmoin.resource;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceFactoryImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;

public class CIMXmiResource extends XMIResourceImpl {

	public static class CIMResourceFactory extends ResourceFactoryImpl {

		@Override
		public Resource createResource(URI uri) {
			return new CIMXmiResource(uri);
		}
	}
	
	public CIMXmiResource(URI uri) {
		super(uri);
		defaultSaveOptions = getDefaultSaveOptions();
	}

	@Override
	protected boolean useUUIDs() {
		return true;
	}

	public void drawNewExtrinsicId(EObject eObj) {
		setID(eObj, EcoreUtil.generateUUID());
	}

	@Override
	public void doSave(OutputStream outputStream, Map<?, ?> options) throws IOException {
		throw new UnsupportedOperationException("save not supported");
	}

	@Override
	public void delete(Map<?, ?> options) throws IOException {
		throw new UnsupportedOperationException("delete not supported");
	}

	protected static Object getOption(Map<?, ?> options, String nameOfOption) {
		Object result = null;
		if (options != null) {
			result = options.get(nameOfOption);
		}
		return result;
	}

	@Override
	@SuppressWarnings("nls")
	public String toString() {
		StringBuilder result = new StringBuilder("<<< Content of resource '" + getURI() + "' >>>\n");
		for (Iterator<EObject> it = EcoreUtil.getAllProperContents(this, true /* resolve */); it.hasNext();) {
			result.append(it.next().toString());
			if (it.hasNext()) {
				result.append("\n");
			}
		}
		return result.toString();
	}
}
