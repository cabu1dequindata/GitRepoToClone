package com.sap.tc.buildplugin.scdef;

import java.io.File;
import java.util.List;

import org.apache.tools.ant.Task;

import com.sap.tc.buildplugin.util.BuildPluginException;

public abstract class EdenBuildPlugin {
	abstract public void execute(
			Task emfTask,
			List<File> sourceDirList,
			List<File> compilePPDirList, File packDir, File tempdir) throws BuildPluginException;
}
