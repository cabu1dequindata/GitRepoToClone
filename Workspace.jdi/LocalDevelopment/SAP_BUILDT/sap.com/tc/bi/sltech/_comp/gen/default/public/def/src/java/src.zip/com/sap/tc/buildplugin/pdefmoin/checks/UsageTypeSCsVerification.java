package com.sap.tc.buildplugin.pdefmoin.checks;

import java.util.*;

import com.sap.sld.api.std.sl.SLD_FunctionalElement;
import com.sap.sld.api.std.sl.SLD_UsageType;
import com.sap.sld.api.std.soft.SLD_ProductVersion;
import com.sap.sld.api.std.soft.SLD_SoftwareComponentVersion;
import com.sap.sld.api.std.soft.SLD_SoftwareUnit;
import com.sap.sld.api.wbem.client.WBEMClient;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.util.BuildPluginException;

/**
 * Check if UT refers to same SCs as associated Feature (Feature can contain more SC than associated
 * UT)
 * 
 * Loop over all products and their features. Check if the UT associated to the feature as Feature
 * Identity and all its Member UTs refer to the same SCs as the feature contains.
 */
public class UsageTypeSCsVerification implements VerificationClass
{
	private final WBEMClient				client;
	private final List<String>				messages;
	private final Hashtable<String, String>	properties;

	private final static String				TECHNOLOGY_TYPE	= "JAVA";
	private final static String				RUNTIME_TYPE	= "J2SE";

	public UsageTypeSCsVerification(WBEMClient client, List<String> messages, Hashtable<String, String> properties)
	{
		this.client = client;
		this.messages = messages;
		this.properties = properties;
	}

	public boolean verify() throws BuildPluginException
	{
		boolean checkOK = true;

		try
		{
			List<SLD_ProductVersion> productVersions = SLD_ProductVersion.getAllProductVersions(client);
			for (SLD_ProductVersion productVersion : productVersions)
			{
				String allProducts = properties.get(VerificationProperties.ALL_PRODUCTS);
				if (VerificationProperties.ALL_PRODUCTS_NO.equals(allProducts))
				{
					String productName = properties.get(VerificationProperties.PRODUCT_NAME);
					String vendor = properties.get(VerificationProperties.VENDOR);
					String versions = properties.get(VerificationProperties.VERSION);

					if (!productVersion.getName().equals(productName) || !productVersion.getVersion().equals(vendor)
							|| !productVersion.getVendor().equals(versions))
					{
						continue;
					}
				}

				List<SLD_SoftwareUnit> softwareUnits = productVersion.getSoftwareUnits();

				// all missing SCs set
				HashSet<SLD_SoftwareComponentVersion> allMissingSCsInUT = new HashSet<SLD_SoftwareComponentVersion>();
				HashSet<SLD_SoftwareComponentVersion> allMissingSCsInFe = new HashSet<SLD_SoftwareComponentVersion>();

				for (SLD_SoftwareUnit softwareUnit : softwareUnits)
				{
					// list containing all SCs referenced by UsageTypes
					HashSet<SLD_SoftwareComponentVersion> allUsageTypeSCs = new HashSet<SLD_SoftwareComponentVersion>();
					// list containing all SCs referenced by Feature
					HashSet<SLD_SoftwareComponentVersion> allFeatureSCs = new HashSet<SLD_SoftwareComponentVersion>();

					allFeatureSCs.addAll(softwareUnit.getSoftwareComponentVersions());

					// check if all SCs referenced by UsageTypes are referenced by the Feature
					SLD_UsageType usageType = softwareUnit.getUsageType();
					if (usageType != null)
					{
						HashSet<SLD_UsageType> allUTs = new HashSet<SLD_UsageType>();
						addAllUTs(usageType, allUTs);

						for (SLD_UsageType ut : allUTs)
						{
							List<SLD_SoftwareComponentVersion> softwareComponents = ut.getSoftwareComponents();
							allUsageTypeSCs.addAll(softwareComponents);

						}

						HashSet<SLD_SoftwareComponentVersion> tmpAllUsageTypeSCs = new HashSet<SLD_SoftwareComponentVersion>(allUsageTypeSCs.size());
						HashSet<SLD_SoftwareComponentVersion> tmpAllFeatureSCs = new HashSet<SLD_SoftwareComponentVersion>(allFeatureSCs.size());
						HashSet<SLD_SoftwareComponentVersion> missingSCsInUT = null;
						HashSet<SLD_SoftwareComponentVersion> missingSCsInFe = null;

						tmpAllUsageTypeSCs.addAll(allUsageTypeSCs);
						tmpAllFeatureSCs.addAll(allFeatureSCs);
						if (!tmpAllFeatureSCs.containsAll(tmpAllUsageTypeSCs))
						{
							if (tmpAllUsageTypeSCs.removeAll(tmpAllFeatureSCs))
							{
								missingSCsInFe = new HashSet<SLD_SoftwareComponentVersion>(tmpAllUsageTypeSCs.size());
								// all SCs contained in UT but missed in Feature
								missingSCsInFe.addAll(tmpAllUsageTypeSCs);
							}
						}

						tmpAllUsageTypeSCs.clear();
						tmpAllFeatureSCs.clear();
						tmpAllUsageTypeSCs.addAll(allUsageTypeSCs);
						tmpAllFeatureSCs.addAll(allFeatureSCs);
						if (!tmpAllUsageTypeSCs.containsAll(tmpAllFeatureSCs))
						{
							if (tmpAllFeatureSCs.removeAll(tmpAllUsageTypeSCs))
							{
								missingSCsInUT = new HashSet<SLD_SoftwareComponentVersion>(tmpAllFeatureSCs.size());
								// all SCs contained in Feature but missed in UT
								missingSCsInUT.addAll(tmpAllFeatureSCs);
							}
						}

						if (missingSCsInFe != null)
						{
							for (SLD_SoftwareComponentVersion sc : missingSCsInFe)
							{
								if (!allMissingSCsInUT.contains(sc) && !allMissingSCsInFe.contains(sc))
								{
									allMissingSCsInFe.add(sc);
									Log.warn("SoftwareComponent \"" + sc.getCaption() + "\" is referenced from UT \"" + usageType.getCaption()
											+ "\" or its members but is not contained in feature \"" + softwareUnit.getCaption() + "\" in Product \""
											+ productVersion.getCaption() + "\".");
									messages.add("SoftwareComponent \"" + sc.getCaption() + "\" is referenced from UT \"" + usageType.getCaption()
											+ "\" or its members but is not contained in feature \"" + softwareUnit.getCaption() + "\" in Product \""
											+ productVersion.getCaption() + "\".");
									checkOK = false;
								}
							}
						}

						if (missingSCsInUT != null)
						{
							for (SLD_SoftwareComponentVersion sc : missingSCsInUT)
							{
								if (TECHNOLOGY_TYPE.equalsIgnoreCase(sc.getTechnologyType()))
								{
									if (!RUNTIME_TYPE.equals(sc.getRuntimeType()))
									{
										if (!allMissingSCsInUT.contains(sc) && !allMissingSCsInFe.contains(sc))
										{
											allMissingSCsInUT.add(sc);
											Log.warn("SoftwareComponent \"" + sc.getCaption() + "\" is contained in feature \"" + softwareUnit.getCaption()
													+ "\" but is not referenced from UT \"" + usageType.getCaption() + "\" or its members " + " in Product \""
													+ productVersion.getCaption() + "\".");
											messages.add("SoftwareComponent \"" + sc.getCaption() + "\" is contained in feature \"" + softwareUnit.getCaption()
													+ "\" but is not referenced from UT \"" + usageType.getCaption() + "\" or its members " + " in Product \""
													+ productVersion.getCaption() + "\".");
											checkOK = false;
										}
									}
								}
							}
						}

					}
				}

			}
		}
		catch (CIMException e)
		{
			throw new BuildPluginException("CIMException while cheking if FUNs reference only SCs available via product. ", e);
		}

		return checkOK;
	}

	private void addAllUTs(SLD_UsageType ut, HashSet<SLD_UsageType> allFEs) throws CIMException
	{
		allFEs.add(ut);

		Set<SLD_FunctionalElement> allMembers = ut.getAllRequiredAndMemberFEs();
		for (SLD_FunctionalElement functionalElement : allMembers)
		{
			if (functionalElement instanceof SLD_UsageType)
			{
				allFEs.add((SLD_UsageType) functionalElement);
			}
		}
	}

	public boolean abortBuild()
	{
		return false;
	}

	public String getDescription()
	{
		return "Check if UT refers to same SC as associated feature";
	}

	public boolean stopOtherVerifications()
	{
		return false;
	}
}
