package com.sap.tc.buildplugin.scdef;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.sap.tc.buildplugin.api.IDataContext;
import com.sap.tc.buildplugin.gen.GeneratorException;
import com.sap.tc.buildplugin.gen.IGenerator;
import com.sap.tc.buildplugin.util.IAntToolkit;
import com.sap.tc.buildplugin.util.IAntToolkit.Element;


public class ScdefTaskGenerator implements IGenerator {

    public void execute( IAntToolkit toolkit, IDataContext localContext, Map<String, List> inputPaths, Map<String, Object> outputPaths, Map<String, List> usedPaths, Map<String, Object> parameters ) throws GeneratorException, IOException {

    	String taskName = getTaskName();
    	toolkit.echo("+++ " + this.getClass().getName() + ": taskName: " + taskName);
        Element sampleComponentsTask = toolkit.createElement( taskName );
        sampleComponentsTask.addAttribute("packdir", outputPaths.get("packdir"));
        sampleComponentsTask.addAttribute("tempdir", outputPaths.get("tempdir"));
        
        toolkit.echo("localContext: " + localContext);
        toolkit.echo("inputPaths: " + inputPaths);
        toolkit.echo("outputPaths: " + outputPaths);
        toolkit.echo("usedPaths: " + usedPaths);
        toolkit.echo("parameters: " + parameters);
        
        extractSourceDirs(toolkit, inputPaths, sampleComponentsTask);
        extractCompilePPDirs(toolkit, inputPaths, sampleComponentsTask);
        
        sampleComponentsTask.render( );
    }

	private void extractCompilePPDirs(IAntToolkit toolkit,
			Map<String, List> inputPaths, Element sampleComponentsTask)
			throws IOException {
		final String dirPurpose = "compile_pp";
		final String dirId = "cdir";
		extractDirectories(toolkit, inputPaths, sampleComponentsTask, dirPurpose,
				dirId);
	}
	
	private void extractSourceDirs(IAntToolkit toolkit,
			Map<String, List> inputPaths, Element sampleComponentsTask)
			throws IOException {
		final String dirPurpose = "source";
		final String dirId = "sdir";
		extractDirectories(toolkit, inputPaths, sampleComponentsTask, dirPurpose,
				dirId);
	}

	private void extractDirectories(IAntToolkit toolkit,
			Map<String, List> inputPaths, Element sampleComponentsTask,
			final String dirPurpose, final String dirId) throws IOException {
		Object directoriesForThisPurpose = inputPaths.get( dirPurpose );
		if (directoriesForThisPurpose == null ) {
			toolkit.echo("inputPaths for purpose "+ dirPurpose + " are undefined, skipping ...");
		} else {
			for ( java.io.File file : (List<java.io.File>) directoriesForThisPurpose ) {
	            toolkit.echo( "File(" + dirPurpose + "): " + file );
	            Element cdir = toolkit.createElement( dirId );
	            cdir.addAttribute( dirId, file );
	            sampleComponentsTask.addChild( cdir );
	        }
		}
	}

    /**
     * Return the name for the task generated for the actual generation
     * @return The name for the task
     */
    protected String getTaskName() {
    	return "ScdefGeneratorTask";
    }
}
