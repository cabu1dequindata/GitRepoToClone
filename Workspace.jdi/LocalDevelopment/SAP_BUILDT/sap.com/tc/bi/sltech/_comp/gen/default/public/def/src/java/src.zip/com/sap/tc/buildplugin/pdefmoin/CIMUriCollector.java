package com.sap.tc.buildplugin.pdefmoin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.eclipse.emf.common.util.URI;

import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IArchiveDescriptor;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pp.api.IDevelopmentComponent;

public class CIMUriCollector {

	public static List<URI> collectUris() {
		IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
		
		List<URI> uris = new ArrayList<URI>();
		addSourceUris(uris, pbi);
		addArchiveUris(uris, pbi);
		
		return uris;
	}
	
	private static void addSourceUris(List<URI> retUris, IPluginBuildInfo pbi) {
		for (File folder : pbi.getDCDirsAsFiles()) {
			addUrisInDir(pbi.getDCVendor(), pbi.getDCName(), computeFolderName(pbi.getRootDir(), folder), folder, retUris);
		}
	}

	private static String[] computeFolderName(File base, File folder) {
		// compute the folder name from pathes: remove common prefix of base from folder and replace eventual back slashes.
		return folder.getPath().substring(base.getPath().length() + 1).replace('\\', '/').split("/");
	}

	private static List<URI> addUrisInDir(String dcVendor, String dcName, String[] pathSegments, File dir, List<URI> ret) {

		for (File f : dir.listFiles()) {
			String[] newPathSegments = Arrays.copyOf(pathSegments, pathSegments.length + 1);
			newPathSegments[pathSegments.length] = f.getName();

			if (f.isDirectory()) {
				addUrisInDir(dcVendor, dcName, newPathSegments, f, ret);
			} else {
				if (isValidFileName(f.getName())) {
					ret.add(CIMUriHandler.createCIMUri(dcVendor, dcName, newPathSegments));
				}
			}
		}
		return ret;
	}
	
	private static boolean isValidFileName(String name) {
		int indexOf = name.lastIndexOf('.');
		return indexOf != -1 && CIMUriHandler.CIM_SUFFIX.contains(name.substring(indexOf));
	}
	
	private static void addArchiveUris(List<URI> retUris, IPluginBuildInfo pbi) {

		// find referenced archives
		List<String> arguments = Collections.emptyList();
		List<IArchiveDescriptor> archiveDescriptors = pbi.getArchiveDescriptors(pbi.getCompilationDirs(), arguments);
		for (IArchiveDescriptor archiveDescriptor : archiveDescriptors) {
			// get archive dc
			IDevelopmentComponent archiveDc = pbi.getDevelopmentComponent(archiveDescriptor.getPublicPartReference());

			// get relevant folders (in all the zips)
			List<String> relevantFolders = new ArrayList<String>();
			relevantFolders.addAll(archiveDc.getPackageFolders());
			relevantFolders.addAll(archiveDc.getSourceFolders());

			// get pp archives (zips) of the archive
			List<File> archiveFiles = archiveDescriptor.getFiles();
			// scan them all
			for (File archiveFile : archiveFiles) {

				if (archiveFile.exists() && archiveFile.isFile()) {
					try {
						ZipFile zipFile = new ZipFile(archiveFile);

						for (Enumeration<? extends ZipEntry> entries = zipFile.entries(); entries.hasMoreElements();) {
							ZipEntry entry = entries.nextElement();

							if (!entry.isDirectory()) {
								String entryName = entry.getName();
								if (entryName != null && isValidFileName(entryName)) {
									// we scan only for relevant folders
									for (String relevantFolder : relevantFolders) {
										if (entryName.startsWith(relevantFolder) && (entryName.length() == relevantFolder.length()
												|| entryName.charAt(relevantFolder.length()) == '/')) {
											// create uri for each file in a
											// relevant folder
											retUris.add(CIMUriHandler.createCIMUri(archiveDc.getVendor(), archiveDc.getName(), entryName));
											break;
										}
									}
								}
							}
						}

					} catch (ZipException e) {
						Log.warn("zip failed (ignored)",e);
					} catch (IOException e) {
						Log.warn("zip failed (ignored)",e);
					}
				}
			}
		}
	}
	
}
