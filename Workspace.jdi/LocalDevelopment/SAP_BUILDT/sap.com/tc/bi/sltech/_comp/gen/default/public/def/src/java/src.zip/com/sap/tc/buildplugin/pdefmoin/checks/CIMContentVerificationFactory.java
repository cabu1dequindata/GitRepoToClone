package com.sap.tc.buildplugin.pdefmoin.checks;

import java.util.Hashtable;
import java.util.List;

import com.sap.sld.api.wbem.client.WBEMClient;

/**
 * Verification Suite for the CIM content
 * 
 */
public class CIMContentVerificationFactory
{
	public static VerificationSuite getVerificationSuite(WBEMClient client, List<String> messages, Hashtable<String, String> properties)
	{
		VerificationSuite checks = new VerificationSuite();
		checks.addVerificationClass(new LineIsNotMissingVerification(client, messages, properties));
		checks.addVerificationClass(new CircularDependenciesVerification(client, messages, properties));
		checks.addVerificationClass(new PartIdVerification(client, messages, properties));
		checks.addVerificationClass(new FunctionalUnitSCsVerification(client, messages, properties));
		checks.addVerificationClass(new UsageTypeSCsVerification(client, messages, properties));

		return checks;
	}
}
