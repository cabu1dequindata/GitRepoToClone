package com.sap.tc.buildplugin.scdef;

import java.io.File;
import java.io.IOException;

import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.*;
import com.sap.tc.buildplugin.gen.IGeneratorCall;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.util.BuildPluginException;
import com.sap.tc.buildplugin.util.IAntToolkit;
import com.sap.tc.buildplugin.util.IAntToolkit.Element;
import com.sap.tc.buildplugin.util.IAntToolkit.FileSet;


public class ScdefBuildFileCreator implements IBuildFileCreator {

	public void render( IAntToolkit toolkit ) throws BuildPluginException, IOException {

        IGlobalPluginUtil gpu = (IGlobalPluginUtil) BuildSessionManager.getFromBuildSession( IGlobalPluginUtil.class.getName( ) );
        try {
            File packdir = gpu.createTempDir("sld_pack01");
            File tempdir = gpu.createTempDir("sld_temp01");
            gpu.addFolderAttribute(packdir, EdenBuildPluginConstants.ATTR_SLDATA_PACKDIR);
            gpu.addFolderAttribute(tempdir, EdenBuildPluginConstants.ATTR_SLDATA_TEMPDIR);

            File sda_dd_xml = new File(tempdir, "sda-dd.xml");

            toolkit.startTarget( "translate" );
            String generatorChainName = getGeneratorChainName();
            Log.info("  +++ " + getClass().getName() + ": chainName: " + generatorChainName);
            IGeneratorCall mmgen = gpu.createGeneratorCall( generatorChainName );
            mmgen.setOutputPath("packdir", packdir.getAbsolutePath());
            mmgen.setOutputPath("tempdir", tempdir.getAbsolutePath());
            mmgen.invoke( );
            toolkit.endTarget( );

            // public parts
            toolkit.startTarget( "createPublicParts" );
            toolkit.packPublicParts( );
            toolkit.endTarget( );
            toolkit.addTargetDependency( "createPublicParts", "translate" );

            // create deployable archive
            // First, investigate if the DC is flagged to contain the complete product model. If this is
            // the case, the DC doesn't need the creation of a deployable SDA unit, so this target can be skipped
            boolean dcContainsCompleteProductModel = ScdefDCUtil.dcContainsCompleteProductModel();
            if(dcContainsCompleteProductModel) {
            	Log.info("  +++ skipping SDA creation, DC contains complete product model");
            } else {
            	Log.info("  +++ forcing SDA creation, DC does not contain complete product model");
	            toolkit.startTarget( "createDeployArchive" );
	            IBuildContext c = (IBuildContext) BuildSessionManager.getFromBuildSession(IBuildContext.class.getName());
	        	String s = c.getAsString("dc_deployDir") + "/" + c.getAsString("dc_deployFile") + ".sda";
	    		toolkit.beginCreateDeployFile( "sap.com~SDA", s, sda_dd_xml.getAbsolutePath(), gpu.createList() );
	            Element option1 = toolkit.createElement( "option" );
	            option1.addAttribute( "key", "software-type" );
	            option1.addAttribute( "value", "CONTENT" );
	            option1.render( );
	            // subtype SL-SDA only for not J2EE sdas
	            Element option2 = toolkit.createElement( "option" );
	            option2.addAttribute( "key", "software-subtype" );
	            option2.addAttribute( "value", "SL-SDA" );
	            option2.render( );
	            FileSet fs = toolkit.createFileSet( packdir );
	            fs.render( );
	            toolkit.endCreateDeployFile( );
	            toolkit.endTarget( );
	            toolkit.addTargetDependency( "createDeployArchive", "createPublicParts" );
        	}

        } catch ( Exception e ) {
            throw new BuildPluginException( "Failed to create build file", e );
        }
    }

    public void destroy( ) throws BuildPluginException {}

    public void initialize( IPluginBuildInfo arg0 ) throws BuildPluginException {}

    protected String getGeneratorChainName() {
    	return "sap.com~sl.scdef_chain";
    }
}
