package com.sap.tc.buildplugin.pdefmoin;

import java.io.*;
import java.util.*;

import javax.xml.transform.TransformerException;

import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceFactoryImpl;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;

import com.sap.lm.slmodel.SlmodelPackage;
import com.sap.sld.api.std.soft.SLD_ProductVersion;
import com.sap.sld.api.wbem.cim.*;
import com.sap.sld.api.wbem.client.WBEMClient;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.sld.api.wbem.sap.SLDElementNames;
import com.sap.tc.buildplugin.gen.GeneratorException;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pdefmoin.checks.*;
import com.sap.tc.buildplugin.pdefmoin.resource.CIMXmiResource;
import com.sap.tc.buildplugin.pdefnwproducts.NWProductsGenerator;
import com.sap.tc.buildplugin.util.BuildPluginException;

public class CIMExportUtil
{

	private final WBEMClient	client;
	private MetamodelToCIMUtil	metamodelToCIMUtil	= null;
	private VirtualCIMOM		virtualCIMOM		= null;

	private static final String	PURPOSE				= "customer";
	
	private List<URI> resources = null;

	public CIMExportUtil(InputStream aModelInputStream) throws CIMException
	{
		virtualCIMOM = new VirtualCIMOM(aModelInputStream);
		client = virtualCIMOM.getWBEMClient();
		metamodelToCIMUtil = new MetamodelToCIMUtil(client);
		// find stuff
		resources = CIMUriCollector.collectUris();
	}

	/**
	 * Export the product given by name, vendor, version with all associated
	 * instances. Also include all required, included and predecessor products and instances.
	 * @see SLD_ProductVersion.#getSLExportList()
	 * @param path
	 * @param productName
	 * @param productVersion
	 * @param productVendor
	 * @param messages
	 * @throws CIMException
	 */
	public void exportCIM(String path, String productName, String productVersion, String productVendor, List<String> messages) throws CIMException
	{
		FileOutputStream out = null;
		try
		{
			File export = new File(path);
			if (!export.exists())
			{
				export.createNewFile();
			}
			out = new FileOutputStream(export);
			
			SLD_ProductVersion masterproduct=null;
			Set<SLD_ProductVersion> productsToExport=new HashSet<SLD_ProductVersion>();
			// find product that should be filtered
			WBEMClient sldclient=virtualCIMOM.getWBEMClient();
			for(SLD_ProductVersion prodvers:SLD_ProductVersion.getAllProductVersions(sldclient))
			{
				if(prodvers.getName().equals(productName) && 
					prodvers.getVendor().equals(productVendor) && 
					prodvers.getVersion().equals(productVersion))
				{
					masterproduct=prodvers;
					productsToExport.add(prodvers);
					break;
				}
					
			}
			if(masterproduct==null)
				throw new CIMException(
						"Failed to find matching product version (Name/Version/Vendor): {0}/{1}/{2}",
						new Object[] { productName, productVersion, productVendor });
			
			List<CIMReference> exportList=new ArrayList<CIMReference>();
			/*
			// find referenced products and add to set:
			// all predecessor products
			CIMElementList<CIMReference> refUpgradePaths = addAssociatorAndReferenceNames(sldclient, exportList, masterproduct.getInstancename(), 
					new ElementName("SAP_ProductUpgradeTarget"), new ElementName("SAP_ProductUpgradePath"),
					SLDElementNames.ROLE_Member,SLDElementNames.ROLE_Collection);
			for(CIMReference refUpgradePath: refUpgradePaths)
			{
				CIMElementList<CIMReference> refSourceProducts = addAssociatorAndReferenceNames(sldclient, exportList, refUpgradePath, 
						new ElementName("SAP_ProductUpgradeSource"), new ElementName("SAP_ProductUpgradePath"),
						SLDElementNames.ROLE_Collection,SLDElementNames.ROLE_Member);
				for(CIMReference refSourceProduct: refSourceProducts)
					productsToExport.add(new SLD_ProductVersion(sldclient, refSourceProduct));
			}
			// all required/included/alt incl instances (recursively)
			for(SLD_SoftwareUnit feature:masterproduct.getSoftwareUnits())
			{
				
				// all products with predecessor instances
			}
			*/
			

			for(SLD_ProductVersion prodvers:productsToExport)
			{
				exportList.addAll(prodvers.getSLExportList());
			}
			
			virtualCIMOM.exportContent(out, exportList, messages);
		}
		catch (IOException e)
		{
			// TODO
			throw new CIMException("CIMExportUtil.0", null, e); //$NON-NLS-1$
		}
		finally
		{
			try
			{
				if (out != null)
				{
					out.close();
				}
			}
			catch (IOException e)
			{
				// TODO
				throw new CIMException("CIMExportUtil.0", null, e); //$NON-NLS-1$
				// LmEditorEditorPlugin.logError(e);
			}
		}
	}
	  /**
	   * Add the names of all associators and references of a source instance to a
	   * collection.
	   * Used for export lists.
	   * @param sldclient client
	   * @param exportNames the collection to fill
	   * @param sourceName the source instance for the enumeration
	   * @param assocClass the association class filter
	   * @param resultClass the result class filter (for associators only)
	   * @param role role of this instance in the association (null for all)
	   * @return list of associator names
	   */
	  private static CIMElementList<CIMReference> addAssociatorAndReferenceNames(WBEMClient sldclient,
	    Collection<CIMReference> exportNames,
	    CIMReference sourceName,
	    ElementName assocClass,
	    ElementName resultClass,ElementName role,ElementName targetrole) throws CIMException
	  {
	    CIMElementList<CIMReference> associatorNames =
	      sldclient.associatorNames(sourceName, assocClass, resultClass, role, targetrole);
	    exportNames.addAll(associatorNames);
	    addReferenceNames(sldclient,exportNames, sourceName, assocClass,role);
	    return associatorNames;
	  }
	  /**
	   * Add the names of all references of a source instance to a collection.
	   * Used for export lists.
	   *
	   * @param sldclient client
	   * @param exportNames the collection to fill
	   * @param sourceName the source instance for the enumeration
	   * @param assocClass the association class filter
	   * @param role role of this instance in the association (null for all)
	   */
	  private static void addReferenceNames(WBEMClient sldclient,
	    Collection<CIMReference> exportNames,
	    CIMReference sourceName,
	    ElementName assocClass,ElementName role) throws CIMException
	  {
	    CIMElementList<CIMReference> referenceNames =
	      sldclient.referenceNames(sourceName, assocClass, role);
	    exportNames.addAll(referenceNames);
	  }
	/**
	 * Generate all XML files
	 * 
	 * @param pathToNwProductsXML
	 *            - path of the nw_products.xml - The content is created from CIM data
	 * @param pathToNwProductsExtendedXML
	 *            - path of the nw_products_extended.xml - The content from nw_products.xml
	 * @param pathToUsageDataXML
	 *            - path of the usage_data.xml - The content from nw_products.xml
	 * @param pathToUtdefXML
	 *            - path of the utdef.xml - The content from nw_products.xml
	 * @param extendedXSL
	 *            - path of the transformation xls for nw_products_extended.xml
	 * @param usageDataXSL
	 *            - path of the transformation xls for usage_data.xml
	 * @param utedefXSL
	 *            - path of the transformation xls for utdef.xml
	 * @param functionsXSL
	 *            - path of the functions xls used from the other xls files
	 * @param messages
	 *            - Log messages
	 * @throws BuildPluginException
	 */
	public void generateXMLFiles(String pathToNwProductsXML, String pathToNwProductsExtendedXML, String pathToUsageDataXML, String pathToUtdefXML,
			String pathToItscenariosXML, String pathToJexcludeXML, File extendedXSL, File usageDataXSL, File utedefXSL, File itscenariosXSL, File jexcludeXSL,
			File functionsXSL, File additionalNodes, List<String> messages) throws BuildPluginException
	{
		NWProductsGenerator generator = new NWProductsGenerator(messages, additionalNodes);

		try
		{
			File nwProducts = new File(pathToNwProductsXML);
			if (!nwProducts.exists())
			{
				nwProducts.createNewFile();
			}

			nwProducts = generator.create(client, nwProducts, "nw_products.xsd");

			File nwProductsExt = tranformXML(nwProducts, extendedXSL, pathToNwProductsExtendedXML, generator, null);

			tranformXML(nwProductsExt, usageDataXSL, pathToUsageDataXML, generator, functionsXSL);

			tranformXML(nwProductsExt, utedefXSL, pathToUtdefXML, generator, functionsXSL);

			tranformXML(nwProductsExt, itscenariosXSL, pathToItscenariosXML, generator, functionsXSL);

			tranformXML(nwProductsExt, jexcludeXSL, pathToJexcludeXML, generator, functionsXSL);

		}
		catch (GeneratorException e)
		{
			throw new BuildPluginException("Could not generate nw_products.xml file.");
		}
		catch (IOException e)
		{
			throw new BuildPluginException("Could not create file: " + pathToNwProductsXML);
		}
		catch (TransformerException e)
		{
			throw new BuildPluginException("Transformation failed: " + e.getMessage());
		}
	}

	protected File tranformXML(File sourceXML, File xsltFile, String resultXMLName, NWProductsGenerator generator, File includedXSLT)
			throws TransformerException, BuildPluginException
	{

		try
		{
			File resultXML = new File(resultXMLName);
			if (!resultXML.exists())
			{
				resultXML.createNewFile();
			}

			if (xsltFile != null)
			{
				resultXML = generator.transformXML(sourceXML, xsltFile, resultXML, PURPOSE, includedXSLT);
			}
			else
			{
				throw new BuildPluginException("Transformation file for creating " + resultXMLName + " not found.");
			}
			return resultXML;
		}
		catch (IOException e)
		{
			throw new BuildPluginException("Could not create file: " + resultXMLName);
		}
	}

	public void convertMOINToCIM(List<String> messages, Hashtable<String, String> properties) throws BuildPluginException
	{
		// instances
		createAllCimInstances();
		// associations
		createAllCimBaseAssociations();

		// filter CIM content (at the moment only SAP_PERSON)
		messages.add("Filter the CIM content.");
		filterContent();

		// test the content
		messages.add("Check if the CIM content is correct.");
		testContent(messages, properties);
	}

	/**
	 * Check if the content is correct. <br>
	 * 
	 * @param messages
	 * @param properties
	 * @throws BuildPluginException
	 */
	private void testContent(List<String> messages, Hashtable<String, String> properties) throws BuildPluginException
	{
		VerificationSuite verificationSuite = CIMContentVerificationFactory.getVerificationSuite(client, messages, properties);
		verificationSuite.verify();
	}

	/**
	 * Filter the CIM content. At the moment only the SAP_Person instances and their associations
	 * are removes
	 */
	private void filterContent()
	{
		filterPersons();
	}

	/**
	 * Remove all SAP_Person instances and their associations
	 */
	private void filterPersons()
	{
		try
		{
			CIMElementList<CIMReference> instanceNames = client.enumerateInstanceNames(SLDElementNames.C_SAP_Person);
			for (CIMReference reference : instanceNames)
			{
				client.deleteInstanceWithReferences(reference);

			}
		}
		catch (CIMException e)
		{
			// TODO
			Log.warn(e.getMessage());
		}
	}

	/**
	 * Create all instances
	 */
	private void createAllCimInstances()
	{
		ResourceSet rs = this.createResourceSet();
		for (URI uri : this.resources) {
			rs.getResource(uri, true);
		}
		for (TreeIterator<Object> objs = EcoreUtil.getAllProperContents(rs, true); objs.hasNext();) {
			Object next = objs.next();
			if(next instanceof EObject) {
				EObject eobj = (EObject) next;
				if (SlmodelPackage.Literals.CIM_MANAGED_ELEMENT.isInstance(eobj)) 
				{
					try
					{
						CIMInstance instance = metamodelToCIMUtil.getCIMInstanceFromRefObject(eobj);
						client.createInstance(instance);
					}
					catch (CIMException e)
					{
						// TODO
						Log.warn(e.getMessage());
					}
				}
			}
		}
		
//		String queryToConvert = "select cimManagedElement from [%s] as cimManagedElement"; //$NON-NLS-1$
//		String query = String.format(queryToConvert, EcoreUtil.getURI(SlmodelPackage.Literals.CIM_MANAGED_ELEMENT).toString());
//		ResultSet instancesSet = mqlQuery.executeQuery(query);
//		EObject[] instances = mqlQuery.getQueryEObjects(instancesSet, "cimManagedElement"); //$NON-NLS-1$
//
//		for (int i = 0; i < instances.length; i++)
//		{
//			try
//			{
//				CIMInstance instance = metamodelToCIMUtil.getCIMInstanceFromRefObject(instances[i]);
//				client.createInstance(instance);
//			}
//			catch (CIMException e)
//			{
//				// TODO
//				Log.warn(e.getMessage());
//			}
//		}
	}

	/**
	 * Create all associations
	 */
	private void createAllCimBaseAssociations()
	{
		ResourceSet rs = this.createResourceSet();
		for (URI uri : this.resources) {
			rs.getResource(uri, true);
		}
		for (TreeIterator<Object> objs = EcoreUtil.getAllProperContents(rs, true); objs.hasNext();) {
			Object next = objs.next();
			if(next instanceof EObject) {
				EObject eobj = (EObject) next;
				if (SlmodelPackage.Literals.CIM_BASE_ASSOCIATION.isInstance(eobj)) 
				{
					try
					{
						CIMInstance instance = metamodelToCIMUtil.getCIMAssociationFromRefObject(eobj);
						client.createInstance(instance);
					}
					catch (CIMException e)
					{
						// TODO
						Log.warn(e.getMessage());
					}
				}
			}
		}
		
//		String queryToConvert = "select cimBaseAssociation from [%s] as cimBaseAssociation"; //$NON-NLS-1$
//		String query = String.format(queryToConvert, EcoreUtil.getURI(SlmodelPackage.Literals.CIM_BASE_ASSOCIATION).toString());
//		ResultSet associationsSet = mqlQuery.executeQuery(query);
//		EObject[] associations = mqlQuery.getQueryEObjects(associationsSet, "cimBaseAssociation"); //$NON-NLS-1$
//
//		for (int i = 0; i < associations.length; i++)
//		{
//			try
//			{
//				CIMInstance instance = metamodelToCIMUtil.getCIMAssociationFromRefObject(associations[i]);
//				client.createInstance(instance);
//			}
//			catch (CIMException e)
//			{
//				// TODO
//				Log.warn(e.getMessage());
//			}
//		}
	}
	
	private ResourceSet createResourceSet() {
		ResourceSetImpl rs = new ResourceSetImpl();
		rs.getURIConverter().getURIHandlers().add(0, new CIMUriHandler());
		rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put(CIMUriHandler.CIM_SUFFIX.substring(1), new CIMXmiResource.CIMResourceFactory());
		return rs;
	}
	
}
