package com.sap.tc.buildplugin.pdefnwproducts;

import java.io.File;
import java.io.IOException;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.*;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

import com.sap.sld.api.std.sl.SLD_FunctionalElement;
import com.sap.sld.api.std.sl.SLD_FunctionalEntity;
import com.sap.sld.api.std.sl.SLD_UsageType;
import com.sap.sld.api.std.soft.SLD_ProductVersion;
import com.sap.sld.api.std.soft.SLD_SoftwareComponentVersion;
import com.sap.sld.api.std.soft.SLD_SoftwareUnit;
import com.sap.sld.api.wbem.cim.CIMElementList;
import com.sap.sld.api.wbem.cim.CIMReference;
import com.sap.sld.api.wbem.client.WBEMClient;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.sld.api.wbem.sap.SLDElementNames;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.util.BuildPluginException;

/**
 * Generates nw_products.xml from EDEN model
 * 
 * @author I054304
 * 
 */
public class NWProductsGenerator
{

	private static final String	INDENT_AMOUNT	= "{http://xml.apache.org/xslt}indent-amount";
	private static final String	NAMESPACE_URI	= "http://www.w3.org/2001/XMLSchema-instance";
	private static final String	QUALIFIED_NAME	= "xsi:noNamespaceSchemaLocation";
	private final List<String>	messages;
	private final Document		doc;

	public NWProductsGenerator(List<String> messages, File additionalNodes) throws BuildPluginException
	{
		this.messages = messages;

		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder;
		Document doc1 = null;
		try
		{
			docBuilder = docBuilderFactory.newDocumentBuilder();

			doc1 = docBuilder.parse(additionalNodes);

			// normalize text representation
			doc1.getDocumentElement().normalize();

		}
		catch (ParserConfigurationException e)
		{
			throw new BuildPluginException("Could not initialize NWProductsGenerator.");
		}
		catch (SAXException e)
		{
			throw new BuildPluginException("Could not initialize NWProductsGenerator");
		}
		catch (IOException e)
		{
			throw new BuildPluginException("Could not initialize NWProductsGenerator");
		}

		this.doc = doc1;
	}

	/**
	 * 
	 * @param client
	 *            WBEM client
	 * 
	 * @return
	 * @throws CIMException
	 */
	protected List<SLD_SoftwareComponentVersion> getAllSoftwareComponents(WBEMClient client) throws CIMException
	{

		List<SLD_SoftwareComponentVersion> scList = SLD_SoftwareComponentVersion.getAllSoftwareComponentVersions(client, true);

		return scList;
	}

	/**
	 * 
	 * @param productVersions
	 *            List of SLD_ProductVersion objects
	 * @return
	 * @throws CIMException
	 */
	protected List<SLD_UsageType> getAllUsageTypes(List<SLD_ProductVersion> productVersions) throws CIMException
	{
		List<SLD_UsageType> elements = new ArrayList<SLD_UsageType>();

		for (SLD_ProductVersion version : productVersions)
		{
			elements.addAll(getAllUsageTypes(version));
		}
		return elements;
	}

	protected HashSet<SLD_UsageType> getAllUsageTypes(SLD_ProductVersion version) throws CIMException
	{
		HashSet<SLD_UsageType> elements = new HashSet<SLD_UsageType>();

		for (SLD_UsageType ut : version.getAllUsageTypes())
		{
			elements.add(ut);
			List<SLD_FunctionalElement> allMembers = ut.getAllMembers(true);
			for (SLD_FunctionalElement functionalElement : allMembers)
			{
				if (functionalElement instanceof SLD_UsageType)
					elements.add((SLD_UsageType) functionalElement);
			}
		}
		return elements;
	}

	protected String calcPurpose(SLD_UsageType ut) throws CIMException
	{
		boolean isInternal = false;
		String purpose;
		for (SLD_SoftwareComponentVersion scv : ut.getSoftwareComponents())
		{
			// SC without feature is inhouse SC
			if (scv.getSoftwareUnits().isEmpty())
			{
				isInternal = true;
			}
		}
		if (isInternal == false)
			purpose = "customer";
		else
			purpose = "inhouse";
		return purpose;
	}

	/**
	 * Append child node to the parent node and set a value of the child node
	 * 
	 * @param dom
	 *            DOM Object
	 * @param parent
	 *            Parent node
	 * @param child
	 *            Name of the child node
	 * @param value
	 *            Value of the child node
	 */
	protected void appendNode(Document dom, Element parent, String child, String value)
	{
		if (parent != null)
		{
			parent.appendChild(dom.createElement(child)).setTextContent(value);
		}
	}

	protected void appendNodeWithAttr(Document dom, Element parent, String childName, String attrName, String attrVal)
	{
		if (parent != null)
		{
			Element childElement = dom.createElement(childName);
			childElement.setAttribute(attrName, attrVal);
			parent.appendChild(childElement);
		}
	}

	protected void scDefSection(Document dom, Element parent, ArrayList<SLD_SoftwareComponentVersion> scv, String purpose) throws DOMException, CIMException
	{
		// logger.info("Create 'sc_definitions' section - purpose: " + purpose);
		Element sc_definitions = dom.createElement("sc_definitions");
		sc_definitions.setAttribute("purpose", purpose);

		// sc
		for (SLD_SoftwareComponentVersion version : scv)
		{

			Element sc = dom.createElement("sc");
			sc.setAttribute("name", version.getName());

			appendNode(dom, sc, "ppms_descr", version.getCaption());
			appendNode(dom, sc, "ppms_key", version.getElementTypeID());
			appendNode(dom, sc, "ppms_version", version.getVersion());
			appendNode(dom, sc, "type", version.getTechnologyType());
			appendNode(dom, sc, "vendor", version.getVendor());
			appendNode(dom, sc, "list_order", "0");

			sc_definitions.appendChild(sc);
		}
		if (parent != null)
			parent.appendChild(sc_definitions);
	}

	protected Node getNodeFromXML(String expression) throws BuildPluginException
	{
		XPath xpath = XPathFactory.newInstance().newXPath();
		Node node = null;

		try
		{
			node = (Node) xpath.evaluate(expression, doc, XPathConstants.NODE);
		}
		catch (XPathExpressionException e)
		{
			throw new BuildPluginException("Wrong xpath expression: ", e);
		}
		return node;
	}

	protected Element getElement(String expression) throws BuildPluginException
	{
		Element clonedNodeElement = null;

		Node nodeFromXml = getNodeFromXML(expression);

		if (nodeFromXml != null)
		{
			if (nodeFromXml.getNodeType() == Node.ELEMENT_NODE)
			{
				Element nodeElement = (Element) nodeFromXml;
				Node clonedNode = nodeElement.cloneNode(true);

				clonedNodeElement = (Element) clonedNode;

			}
		}

		return clonedNodeElement;
	}

	protected void appendNodeFromXml(String expression, Document dom, Element parent) throws BuildPluginException
	{
		Element element = getElement(expression);
		if (element != null)
		{
			Node child = dom.importNode(element, true);
			parent.appendChild(child);
		}
	}

	protected void dplListDefSection(Document dom, Element parent, String productName) throws BuildPluginException
	{

		String expression = "/product_definitions/product[@name='" + productName + "']/deploy_list_definitions";

		appendNodeFromXml(expression, dom, parent);
	}

	protected void predecessorsSection(Document dom, String productName, Element parent, String utName) throws BuildPluginException
	{

		String expression = "/product_definitions/product" + "[@name='" + productName + "']/usage_type_definitions/usage_type[@name='" + utName
				+ "']/predecessors";

		appendNodeFromXml(expression, dom, parent);
	}

	protected void defaultsSection(Document dom, String productName, Element parent) throws BuildPluginException
	{

		String expression = "/product_definitions/product[@name='" + productName + "']/defaults";

		appendNodeFromXml(expression, dom, parent);
	}

	protected void internalSection(Document dom, String productName, Element parent) throws BuildPluginException
	{

		String expression = "/product_definitions/product[@name='" + productName + "']/internal";

		appendNodeFromXml(expression, dom, parent);
	}

	protected String getCodeMapping(String productName) throws BuildPluginException
	{

		String code = "";
		String expression = "/product_definitions/product[@name='" + productName + "']/code";

		Node node = getNodeFromXML(expression);

		if (node != null)
		{
			code = node.getTextContent();
		}

		return code != "" ? code : productName;
	}

	protected String getListOrder(String productName, String utName) throws BuildPluginException
	{

		String expression = "/product_definitions/product" + "[@name='" + productName + "']/usage_type_definitions/usage_type[@name='" + utName
				+ "']/list_order";

		String list_order = "";
		Node node = getNodeFromXML(expression);

		if (node != null)
		{
			list_order = node.getTextContent();
		}

		return list_order != "" ? list_order : "0";
	}

	protected String getUtNameOffset(String productName, String utName) throws BuildPluginException
	{

		String expression = "/product_definitions/product" + "[@name='" + productName + "']/usage_type_definitions/usage_type[@name='" + utName + "']/offset";

		String offset = "";
		Node node = getNodeFromXML(expression);

		if (node != null)
		{
			offset = node.getTextContent();
		}

		if (offset != "")
		{

			int size = 4 * Integer.parseInt(offset);

			StringBuffer sb = new StringBuffer(size);
			for (int i = 0; i < sb.capacity(); i++)
			{
				sb.append(' ');
			}
			String s = sb.toString();
			return s;
		}

		return offset;
	}

	// protected String getPartID(String productName, String utName)
	// throws BuildPluginException {
	// String expression = "/product_definitions/product[@name='"
	// + productName + "']/usage_type_definitions/usage_type[@name='"
	// + utName + "']/part_id";
	//
	// Node part_id = getNodeFromXML(expression);
	//
	// if (part_id != null)
	// return part_id.getTextContent();
	// else
	// return "-";
	// }

	protected String formatPPMSid(String ppmsID)
	{
		if (ppmsID != null && ppmsID.length() != 20)
		{
			try
			{
				String format = "%020d";
				Integer id = Integer.valueOf(ppmsID);
				ppmsID = String.format(format, id);
			}
			catch (NumberFormatException e)
			{
				Log.warn("ppms guid '" + ppmsID + "' is not a number!");
				loggMessage("ppms guid '" + ppmsID + "' is not a number!");
			}
		}
		return ppmsID;
	}

	/**
	 * 
	 * @param productVersions
	 *            List of SLD_ProductVersion objects
	 * @param client
	 * @param destDir
	 *            directory where the XML file will be created
	 * @throws ParserConfigurationException
	 * @throws CIMException
	 * @throws DOMException
	 * @throws BuildPluginException
	 * 
	 */
	protected Document createDOMTree(List<SLD_ProductVersion> productVersions, String nwXSD, WBEMClient client) throws ParserConfigurationException,
			DOMException, CIMException, BuildPluginException
	{

		// product_definitions
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		dbf.setValidating(true);
		dbf.setNamespaceAware(true);

		DocumentBuilder db = dbf.newDocumentBuilder();
		Document dom = db.newDocument();

		Element root = dom.createElement("product_definitions");
		root.setAttributeNS(NAMESPACE_URI, QUALIFIED_NAME, nwXSD);
		dom.appendChild(root);

		// ****************************************************************************************
		// sc_definitions

		ArrayList<SLD_SoftwareComponentVersion> aCustomer = new ArrayList<SLD_SoftwareComponentVersion>();
		ArrayList<SLD_SoftwareComponentVersion> aInhouse = new ArrayList<SLD_SoftwareComponentVersion>();

		// sc
		List<SLD_SoftwareComponentVersion> allSoftwareComponents = getAllSoftwareComponents(client);
		// sort SCs
		Collections.sort(allSoftwareComponents, getSoftwareComponentVersionComparator());
		for (SLD_SoftwareComponentVersion version : allSoftwareComponents)
		{
			// SC without Software feature is inhouse SC
			if (version.getSoftwareUnits().isEmpty())
				aInhouse.add(version);
			else
				aCustomer.add(version);
		}
		if (aCustomer.size() > 0)
			scDefSection(dom, root, aCustomer, "customer");
		if (aInhouse.size() > 0)
			scDefSection(dom, root, aInhouse, "inhouse");

		// ******************************************************************************************

		// ******************************************************************************************
		// group_definitions
		// logger.info("Create 'group_definitions' section");
		Element group_definitions = dom.createElement("group_definitions");
		List<SLD_UsageType> allUsageTypesForAllProducts = SLD_UsageType.getAllUsageTypes(client, true);// productVersions);
		// sort FunctionalElements
		Collections.sort(allUsageTypesForAllProducts, getFunctionalEntityComparator());
		for (SLD_UsageType ut : allUsageTypesForAllProducts)
		{
			// generate groups only for small usage types or UsageTypes with SCs
			if (ut.getProducts().isEmpty() || !ut.getSoftwareComponents().isEmpty())
			{
				Element group = dom.createElement("group");
				group.setAttribute("name", ut.getName());

				// group_ref
				List<SLD_UsageType> allMembers = getAllMemberUsageTypes(ut);
				// sort all members for this FunctionalElement
				Collections.sort(allMembers, getFunctionalEntityComparator());
				for (SLD_UsageType mUt : allMembers)
				{
					Element group_ref = dom.createElement("group_ref");
					group_ref.setAttribute("name", mUt.getName());
					group.appendChild(group_ref);
				}
				// sc_ref
				List<SLD_SoftwareComponentVersion> softwareComponents = ut.getSoftwareComponents();
				// sort all SCs for this FunctionalElement
				Collections.sort(softwareComponents, getSoftwareComponentVersionComparator());
				for (SLD_SoftwareComponentVersion scv : softwareComponents)
				{
					Element sc_ref = dom.createElement("sc_ref");
					sc_ref.setAttribute("name", scv.getName());
					group.appendChild(sc_ref);
				}
				group_definitions.appendChild(group);
			}

		}
		root.appendChild(group_definitions);
		// logger.info("Done! - 'group_definitions' section");
		// *******************************************************************************************

		// ******************************************************************************************
		// product
		// logger.info("Create 'product' section");
		int i = 500;
		for (SLD_ProductVersion version : productVersions)
		{

			String productName = version.getName();
			String productCode = getCodeMapping(version.getName());

			Element product = dom.createElement("product");
			product.setAttribute("name", productCode);

			if (productName != null)
				defaultsSection(dom, productName, product);

			appendNode(dom, product, "ppms_short_name", version.getName());
			appendNode(dom, product, "ppms_long_name", version.getCaption());
			if (version.getProduct() != null)
			{
				appendNode(dom, product, "ppms_product_guid", formatPPMSid(version.getProduct().getPPMSNumber()));
			}
			appendNode(dom, product, "ppms_product_version_guid", formatPPMSid(version.getPPMSNumber()));
			appendNode(dom, product, "vendor", version.getVendor());
			appendNode(dom, product, "code", productCode);// version.getIdentifyingNumber());
			appendNode(dom, product, "release", version.getVersion());

			// **********************************************************************************
			// deploy_list_definitions

			if (productName != null)
				dplListDefSection(dom, product, productName);

			// end deploy_list_definitions
			// **********************************************************************************

			// *******************************************************************************************
			// usage_type_definitions
			// logger.info("Create 'usage_type_definitions' section");

			Element usage_type_definitions = dom.createElement("usage_type_definitions");

			List<SLD_UsageType> allUsageTypes = new ArrayList<SLD_UsageType>(getAllUsageTypes(version));
			// sort all UTs for this product
			Collections.sort(allUsageTypes, getFunctionalEntityComparator());
			for (SLD_UsageType ut : allUsageTypes)
			{
				Element usage_type = dom.createElement("usage_type");
				usage_type.setAttribute("name", ut.getName());

				usage_type.setAttribute("internal", Boolean.toString(isInternalUT(client, ut)));

				// parent
				List<SLD_UsageType> requiredUTs = getOnlyUsageType(ut.getRequiredFEs());
				Collections.sort(requiredUTs, getFunctionalEntityComparator());
				for (SLD_UsageType requiredUT : requiredUTs)
				{
					Element parent = dom.createElement("parent");
					parent.setAttribute("name", requiredUT.getName());
					usage_type.appendChild(parent);
				}

				// ************************************************************************
				String ppms_feature_id = "";
				List<SLD_SoftwareUnit> softwareUnits = ut.getSoftwareUnits();
				Collections.sort(softwareUnits, getSoftwareUnitComparator());
				for (SLD_SoftwareUnit su : softwareUnits)
				{
					if (version.getName().equals(su.getProductName()))
					{
						ppms_feature_id = su.getName();

						// fill the ppms_feature_id with leading zeros (max size 25)
						try
						{
							String format = "%025d";
							Integer id = Integer.valueOf(ppms_feature_id);
							ppms_feature_id = String.format(format, id);
						}
						catch (NumberFormatException e)
						{
							loggMessage("ppms_feature_id '" + ppms_feature_id + "' is not a number!");
						}
					}
				}
				// ************************************************************************

				// String part_id = getPartID(productName, ut.getName()) == "-" ? Integer
				// .toString(i++)
				// : getPartID(productName, ut.getName());
				String part_id = ut.getElementTypeID(); // get part_id (key for UTL table) from
				// ElementTypeID of EDEN usage type

				appendNode(dom, usage_type, "purpose", calcPurpose(ut)); // ??????????????????
				// appendNode(dom, usage_type, "part_id",
				// Integer.toString(i++));
				appendNode(dom, usage_type, "part_id", part_id);
				if (ppms_feature_id != "")
					appendNode(dom, usage_type, "ppms_feature_id", ppms_feature_id);
				appendNode(dom, usage_type, "short_display_name", ut.getCaption());
				appendNode(dom, usage_type, "long_display_name", getUtNameOffset(productName, ut.getName()) + ut.getDescription());
				appendNode(dom, usage_type, "description", ut.getDescription());
				appendNode(dom, usage_type, "vendor", ut.getVendor());
				appendNode(dom, usage_type, "list_order", getListOrder(productName, ut.getName()));

				// group_ref to small usage types or usage types with SCs
				if (!ut.getSoftwareComponents().isEmpty())
				{
					Element group_ref = dom.createElement("group_ref");
					group_ref.setAttribute("name", ut.getName());
					usage_type.appendChild(group_ref);
				}

				List<SLD_UsageType> requiredUTS = getAllMemberUsageTypes(ut);
				// List<SLD_UsageType> requiredUTS = getOnlyUsageType(ut.getAllMembers(false));
				Collections.sort(requiredUTS, getFunctionalEntityComparator());
				for (SLD_UsageType fe : requiredUTS)
				{
					Element group_ref = dom.createElement("group_ref");
					group_ref.setAttribute("name", fe.getName());
					usage_type.appendChild(group_ref);
				}

				if (productName != null)
					predecessorsSection(dom, productName, usage_type, ut.getName());

				usage_type_definitions.appendChild(usage_type);
			}
			product.appendChild(usage_type_definitions);
			// logger.info("Done! - 'usage_type_definitions' section");
			// *******************************************************************************************

			// *******************************************************************************************
			// scenario_definitions
			// logger.info("Create 'usage_type_definitions' section");

			Element scenario_definitions = dom.createElement("scenario_definitions");

			List<SLD_UsageType> allTopLevelUsageTypes = version.getAllUsageTypes();
			// sort all UTs for this product
			Collections.sort(allTopLevelUsageTypes, getFunctionalEntityComparator());
			for (SLD_UsageType ut : allTopLevelUsageTypes)
			{
				// TODO is this code still needed
				Element scenario = dom.createElement("scenario");
				scenario.setAttribute("id", ut.getName());

				appendNode(dom, scenario, "purpose", calcPurpose(ut));
				// depends
				List<SLD_UsageType> requiredUTs = getOnlyUsageType(ut.getRequiredFEs());
				Collections.sort(requiredUTs, getFunctionalEntityComparator());
				for (SLD_UsageType fe : requiredUTs)
				{
					Element depends = dom.createElement("depends");
					depends.setAttribute("scenario", fe.getName());
					scenario.appendChild(depends);
				}

				appendNode(dom, scenario, "name", ut.getName());
				appendNode(dom, scenario, "description", ut.getDescription());
				appendNode(dom, scenario, "is_allowed", "true");
				appendNode(dom, scenario, "need_sld", "false");
				appendNode(dom, scenario, "is_mandatory", "false");
				appendNode(dom, scenario, "need_configuration", "false");
				appendNode(dom, scenario, "development_zero_admin_template", "instance_development");
				appendNode(dom, scenario, "productive_zero_admin_template", "instance_development");
				// appendNode(dom, scenario, "usage_type_ref", ut.getName());
				appendNodeWithAttr(dom, scenario, "usage_type_ref", "name", ut.getName());

				scenario_definitions.appendChild(scenario);
			}
			product.appendChild(scenario_definitions);
			// logger.info("Done! - 'usage_type_definitions' section");
			// *******************************************************************************************

			if (productName != null)
				internalSection(dom, productName, product);

			root.appendChild(product);
		}

		// logger.info("Done! - 'product' section");
		// ******************************************************************************************
		return dom;
	}

	/**
	 * Return all Members of type UsageType for this UsageType
	 * 
	 * @param ut
	 * @return
	 * @throws CIMException
	 */
	private List<SLD_UsageType> getAllMemberUsageTypes(SLD_UsageType ut) throws CIMException
	{
		List<SLD_UsageType> elements = new ArrayList<SLD_UsageType>();
		List<SLD_FunctionalElement> allMembers = ut.getAllMembers(false);
		for (SLD_FunctionalElement functionalElement : allMembers)
		{
			if (functionalElement instanceof SLD_UsageType)
				elements.add((SLD_UsageType) functionalElement);
		}
		return elements;
	}

	/**
	 * UsageType is internal UsageType (small UsageType) when it is CoreMember of another UsageType
	 * 
	 * @param client
	 * @param ut
	 * @return true if the UsageType is CoreMember of another UsageType, else return false
	 * @throws CIMException
	 */
	private boolean isInternalUT(WBEMClient client, SLD_UsageType ut) throws CIMException
	{
		CIMElementList<CIMReference> groupComponents = client.associatorNames(ut.getInstancename(), SLDElementNames.C_SAP_CoreMemberOfFunctionalElement,
				SLDElementNames.C_SAP_UsageType, SLDElementNames.ROLE_PartComponent, SLDElementNames.ROLE_GroupComponent);

		return !groupComponents.isEmpty();
	}

	protected File createXMLFile(Document dom, File nwprodXml) throws TransformerException
	{

		// Use a Transformer for output
		TransformerFactory tFactory = TransformerFactory.newInstance();
		tFactory.setAttribute("indent-number", new Integer(4));
		Transformer transformer = tFactory.newTransformer();
		transformer.setOutputProperty(INDENT_AMOUNT, "4");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");

		DOMSource source = new DOMSource(dom);

		StreamResult result = new StreamResult(nwprodXml);

		transformer.transform(source, result);

		loggMessage("File '" + nwprodXml.getAbsolutePath() + "' is created!");

		return nwprodXml;
	}

	public File create(WBEMClient client, File nwprodXml, String nwXSD) throws BuildPluginException
	{

		File xmlFile = null;

		try
		{
			if (client != null)
			{
				List<SLD_ProductVersion> productVersions = SLD_ProductVersion.getAllProductVersions(client);
				// sort ProductVersion
				Collections.sort(productVersions, getProductVersionComparator());

				Document dom = createDOMTree(productVersions, nwXSD, client);
				xmlFile = createXMLFile(dom, nwprodXml);
			}
			else
			{
				throw new BuildPluginException("WBEM clinet is null.");
			}
		}
		catch (TransformerException e)
		{
			throw new BuildPluginException("Error while creating file " + nwprodXml);
		}
		catch (CIMException e)
		{
			throw new BuildPluginException("Error while creating file " + nwprodXml);
		}
		catch (DOMException e)
		{
			throw new BuildPluginException("Error while creating file " + nwprodXml);
		}
		catch (ParserConfigurationException e)
		{
			throw new BuildPluginException("Error while creating file " + nwprodXml, e);
		}

		return xmlFile;
	}

	public File transformXML(File xmlFile, File xsltFile, File resultXMLFile, String purpose, File pathToXslt) throws TransformerException
	{

		Source xmlSource = new StreamSource(xmlFile);
		Source xsltSource = new StreamSource(xsltFile);

		TransformerFactory factory = TransformerFactory.newInstance();
		factory.setURIResolver(new UriResolver(pathToXslt));
		factory.setAttribute("indent-number", new Integer(4));

		Transformer trans = factory.newTransformer(xsltSource);
		trans.setParameter("purpose", purpose);
		trans.setOutputProperty(OutputKeys.INDENT, "yes");
		trans.setOutputProperty(INDENT_AMOUNT, "4");

		Result result = new StreamResult(resultXMLFile);

		trans.transform(xmlSource, result);

		loggMessage("File '" + resultXMLFile.getAbsolutePath() + "' is created!");

		return resultXMLFile;
	}

	protected void loggMessage(String msg)
	{
		messages.add(msg);
	}

	private List<SLD_UsageType> getOnlyUsageType(List<? extends SLD_FunctionalEntity> fes)
	{
		List<SLD_UsageType> result = new ArrayList<SLD_UsageType>();
		for (SLD_FunctionalEntity fe : fes)
		{
			if (fe instanceof SLD_UsageType)
				result.add((SLD_UsageType) fe);
		}
		return result;
	}

	private Comparator<SLD_FunctionalEntity> getFunctionalEntityComparator()
	{
		return new Comparator<SLD_FunctionalEntity>()
		{
			public int compare(SLD_FunctionalEntity o1, SLD_FunctionalEntity o2)
			{
				if (o1 != null && o2 != null)
				{
					try
					{
						return o1.getName().compareTo(o2.getName());
					}
					catch (CIMException e)
					{
						loggMessage("CIMException while retireving SLD_FunctionalEntity name. " + e.getMessage());
					}
				}
				return 0;
			}
		};
	}

	private Comparator<SLD_SoftwareComponentVersion> getSoftwareComponentVersionComparator()
	{
		return new Comparator<SLD_SoftwareComponentVersion>()
		{
			public int compare(SLD_SoftwareComponentVersion o1, SLD_SoftwareComponentVersion o2)
			{
				if (o1 != null && o2 != null)
				{
					try
					{
						return o1.getName().compareTo(o2.getName());
					}
					catch (CIMException e)
					{
						loggMessage("CIMException while retireving SLD_SoftwareComponentVersion name. " + e.getMessage());
					}
				}
				return 0;
			}
		};
	}

	private Comparator<SLD_SoftwareUnit> getSoftwareUnitComparator()
	{
		return new Comparator<SLD_SoftwareUnit>()
		{
			public int compare(SLD_SoftwareUnit o1, SLD_SoftwareUnit o2)
			{
				if (o1 != null && o2 != null)
				{
					try
					{
						return o1.getName().compareTo(o2.getName());
					}
					catch (CIMException e)
					{
						loggMessage("CIMException while retireving SLD_SoftwareUnit name. " + e.getMessage());
					}
				}
				return 0;
			}
		};
	}

	private Comparator<SLD_ProductVersion> getProductVersionComparator()
	{
		return new Comparator<SLD_ProductVersion>()
		{
			public int compare(SLD_ProductVersion o1, SLD_ProductVersion o2)
			{
				if (o1 != null && o2 != null)
				{
					try
					{
						return o1.getName().compareTo(o2.getName());
					}
					catch (CIMException e)
					{
						loggMessage("CIMException while retireving SLD_ProductVersion name. " + e.getMessage());
					}
				}
				return 0;
			}
		};
	}
}
