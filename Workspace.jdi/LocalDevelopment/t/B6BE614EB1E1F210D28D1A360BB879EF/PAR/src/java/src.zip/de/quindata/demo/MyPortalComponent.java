package de.quindata.demo;
 
import com.sapportals.portal.prt.component.*;

public class MyPortalComponent extends AbstractPortalComponent
{
    public void doContent(IPortalComponentRequest request, IPortalComponentResponse response)
    {

    }
}